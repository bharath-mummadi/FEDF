
export const books = [
{ title: "JavaScript Essentials", author: "John Doe", price: 499, availability: "in stock"
},
{ title: "Learn React", author: "Jane Smith", price: 699, availability: "in stock" },
{ title: "Node.js in Action", author: "Mark Lee", price: 599, availability: "out of stock" },
{ title: "Python for Everyone", author: "Ramya Krishna", price: 450, availability: "in stock" }
];